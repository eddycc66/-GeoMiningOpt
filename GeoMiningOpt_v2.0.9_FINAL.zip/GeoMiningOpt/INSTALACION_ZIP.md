# Instrucciones de Instalación desde ZIP

## Archivo ZIP Creado

📦 **GeoMiningOpt.zip** está listo en:
```
d:\DOCENCIA UNIVERSITARIA\Siglo XX\Módulo 11\modelos_qgis\mejorar_Imagen_satelital\GeoMiningOpt.zip
```

## Pasos para Instalar en QGIS

### 1. Instalar Dependencias (PRIMERO)

Antes de instalar el plugin, instala `earthengine-api`:

**En Windows (OSGeo4W Shell):**
```bash
# Abrir OSGeo4W Shell como administrador
pip install earthengine-api
```

**En Linux/Mac:**
```bash
pip3 install earthengine-api
```

### 2. Instalar Plugin desde ZIP

1. **Abrir QGIS**

2. **Ir a Complementos:**
   - Menú: `Complementos` > `Administrar e instalar complementos`

3. **Seleccionar "Instalar desde ZIP":**
   - Hacer clic en la pestaña `Instalar desde ZIP`

4. **Seleccionar el archivo:**
   - Hacer clic en `...` (Browse)
   - Navegar a: `d:\DOCENCIA UNIVERSITARIA\Siglo XX\Módulo 11\modelos_qgis\mejorar_Imagen_satelital\`
   - Seleccionar: `GeoMiningOpt.zip`
   - Hacer clic en `Instalar complemento`

5. **Esperar confirmación:**
   - Verás un mensaje: "Plugin installed successfully"
   - Si aparece advertencia sobre plugins de terceros, hacer clic en `Sí`

6. **Cerrar el diálogo**

### 3. Verificar Instalación

1. **Verificar que aparece en el menú:**
   - Menú: `Complementos` > `GeoMiningOpt` > `Mineral Exploration (GEE)`

2. **Verificar icono en la barra de herramientas:**
   - Buscar el icono del plugin en la barra de herramientas

### 4. Primer Uso

1. **Abrir el plugin:**
   - Clic en el icono o menú

2. **Autenticarse con Google Earth Engine:**
   - Clic en `Authenticate`
   - Se abrirá el navegador
   - Iniciar sesión con tu cuenta de Google
   - Autorizar el acceso
   - Copiar el código de verificación
   - Pegarlo en la terminal/consola que se abrió

3. **Verificar autenticación:**
   - El estado debe cambiar a "✅ Authenticated"

## Contenido del ZIP

El archivo ZIP contiene todos estos archivos:

```
GeoMiningOpt/
├── __init__.py                    # Inicialización del plugin
├── metadata.txt                   # Metadatos del plugin
├── geomining_opt.py              # Clase principal
├── geomining_dialog.py           # Lógica del diálogo
├── geomining_dialog_base.ui      # Interfaz Qt Designer
├── gee_processor.py              # Procesador de Google Earth Engine
├── map_composer.py               # Generador de mapas profesionales
├── resources.qrc                 # Recursos Qt
├── resources.py                  # Recursos compilados
├── icon.png                      # Icono del plugin
├── README.md                     # Documentación de usuario
└── INSTALL.md                    # Guía de instalación
```

## Solución de Problemas

### Error: "Plugin is broken"

**Causa:** Falta `earthengine-api`

**Solución:**
```bash
pip install earthengine-api
```

### Error: "No module named 'ee'"

**Causa:** La librería no está en el Python de QGIS

**Solución:**
```bash
# Desde OSGeo4W Shell
python3 -m pip install earthengine-api
```

### Plugin no aparece después de instalar

**Solución:**
1. Cerrar QGIS completamente
2. Reabrir QGIS
3. Ir a `Complementos` > `Administrar e instalar complementos` > `Instalados`
4. Buscar `GeoMiningOpt` y marcar la casilla

### Error al abrir el plugin

**Solución:**
1. Abrir la consola de Python en QGIS: `Complementos` > `Consola de Python`
2. Ver los errores en rojo
3. Si dice "No module named 'ee'", instalar earthengine-api
4. Si dice error en UI, puede que falte compilar recursos (normalmente no necesario)

## Desinstalar

Si necesitas desinstalar:

1. `Complementos` > `Administrar e instalar complementos`
2. Buscar `GeoMiningOpt`
3. Hacer clic en `Desinstalar complemento`

## Reinstalar (si haces cambios)

1. Desinstalar el plugin actual
2. Cerrar QGIS
3. Crear nuevo ZIP con los cambios
4. Reabrir QGIS
5. Instalar desde el nuevo ZIP

## Notas Importantes

⚠️ **El ZIP debe contener la carpeta GeoMiningOpt con todos los archivos dentro**, no los archivos sueltos.

✅ **Estructura correcta del ZIP:**
```
GeoMiningOpt.zip
└── GeoMiningOpt/
    ├── __init__.py
    ├── metadata.txt
    ├── ...
```

❌ **Estructura incorrecta:**
```
GeoMiningOpt.zip
├── __init__.py
├── metadata.txt
├── ...
```

## Próximos Pasos

Después de instalar:

1. Autenticarse con GEE
2. Probar con un área pequeña primero
3. Verificar que se exporta a Google Drive
4. Generar un mapa profesional de prueba

¡Listo para probar! 🚀
