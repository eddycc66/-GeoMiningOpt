# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Map Composer
 Professional map layout generation for mineral exploration results
                              -------------------
        begin                : 2026-01-06
        copyright            : (C) 2026 by Edwin Condori
        email                : eddycc66@gmail.com
 ***************************************************************************/
"""

from qgis.core import (QgsProject, QgsPrintLayout, QgsLayoutItemMap,
                        QgsLayoutItemLabel, QgsLayoutItemLegend,
                        QgsLayoutItemScaleBar, QgsLayoutItemPicture,
                        QgsLayoutPoint, QgsLayoutSize, QgsUnitTypes,
                        QgsLayoutExporter, QgsReadWriteContext,
                        QgsLayoutItemShape, QgsSimpleFillSymbolLayer,
                        QgsFillSymbol, QgsLayoutItemPolygon, QgsLayoutItemPage)
from qgis.PyQt.QtCore import QRectF, QPointF, QSizeF
from qgis.PyQt.QtGui import QColor, QFont
from datetime import datetime


class MapComposer:
    """
    Professional map layout composer for mineral exploration results
    
    Creates publication-quality maps with:
    - Scale bar
    - North arrow
    - Legend
    - Title block
    - Coordinate grid
    - Metadata panel
    """
    
    def __init__(self, iface):
        """Initialize map composer"""
        self.iface = iface
        self.project = QgsProject.instance()
        
    def create_professional_layout(self, results, aoi_geometry, sensors, 
                                   start_date, end_date):
        """
        Create professional map layout
        
        Args:
            results: dict with analysis results
            aoi_geometry: QgsGeometry
            sensors: list of sensor names
            start_date: str
            end_date: str
            
        Returns:
            QgsPrintLayout
        """
        # Create layout
        layout = QgsPrintLayout(self.project)
        layout.initializeDefaults()
        layout.setName(f"Mineral_Exploration_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        
        # Set page size (A3 landscape)
        page_collection = layout.pageCollection()
        page = page_collection.page(0)
        page.setPageSize('A3', QgsLayoutItemPage.Landscape)
        
        # Add map
        map_item = self.add_map(layout, aoi_geometry)
        
        # Add title
        self.add_title(layout, sensors, start_date, end_date)
        
        # Add legend
        self.add_legend(layout, map_item)
        
        # Add scale bar
        self.add_scale_bar(layout, map_item)
        
        # Add north arrow
        self.add_north_arrow(layout)
        
        # Add metadata panel
        self.add_metadata(layout, results, aoi_geometry, sensors)
        
        # Add to project
        self.project.layoutManager().addLayout(layout)
        
        return layout
        
    def add_map(self, layout, aoi_geometry):
        """Add map item to layout"""
        map_item = QgsLayoutItemMap(layout)
        map_item.attemptSetSceneRect(QRectF(10, 40, 380, 250))
        
        # Set extent to AOI
        canvas = self.iface.mapCanvas()
        map_item.setExtent(aoi_geometry.boundingBox())
        map_item.setBackgroundColor(QColor(255, 255, 255))
        
        # Enable grid
        map_item.grid().setEnabled(True)
        map_item.grid().setIntervalX(0.1)  # Adjust based on extent
        map_item.grid().setIntervalY(0.1)
        map_item.grid().setAnnotationEnabled(True)
        
        layout.addLayoutItem(map_item)
        
        return map_item
        
    def add_title(self, layout, sensors, start_date, end_date):
        """Add title block"""
        title = QgsLayoutItemLabel(layout)
        title.attemptSetSceneRect(QRectF(10, 10, 380, 25))
        
        sensor_text = ", ".join([s.upper() for s in sensors])
        title_text = f"<b>MINERAL EXPLORATION ANALYSIS</b><br/>"
        title_text += f"<i>Multi-Sensor Analysis: {sensor_text}</i><br/>"
        title_text += f"<small>Period: {start_date} to {end_date}</small>"
        
        title.setText(title_text)
        title.setFont(QFont("Arial", 16, QFont.Bold))
        title.setHAlign(Qt.AlignCenter)
        title.setBackgroundEnabled(True)
        title.setBackgroundColor(QColor(230, 230, 230))
        
        layout.addLayoutItem(title)
        
    def add_legend(self, layout, map_item):
        """Add legend"""
        legend = QgsLayoutItemLegend(layout)
        legend.attemptSetSceneRect(QRectF(300, 300, 90, 100))
        legend.setLinkedMap(map_item)
        legend.setTitle("Legend")
        legend.setBackgroundEnabled(True)
        legend.setBackgroundColor(QColor(255, 255, 255, 200))
        
        layout.addLayoutItem(legend)
        
    def add_scale_bar(self, layout, map_item):
        """Add scale bar"""
        scale_bar = QgsLayoutItemScaleBar(layout)
        scale_bar.attemptSetSceneRect(QRectF(10, 300, 100, 20))
        scale_bar.setLinkedMap(map_item)
        scale_bar.setUnits(QgsUnitTypes.DistanceKilometers)
        scale_bar.setNumberOfSegments(4)
        scale_bar.setHeight(5)
        scale_bar.setBackgroundEnabled(True)
        scale_bar.setBackgroundColor(QColor(255, 255, 255, 200))
        
        layout.addLayoutItem(scale_bar)
        
    def add_north_arrow(self, layout):
        """Add north arrow"""
        north_arrow = QgsLayoutItemPicture(layout)
        north_arrow.attemptSetSceneRect(QRectF(360, 300, 30, 30))
        
        # Use default north arrow
        svg_path = ":/images/north_arrows/layout_default_north_arrow.svg"
        north_arrow.setPicturePath(svg_path)
        north_arrow.setBackgroundEnabled(True)
        north_arrow.setBackgroundColor(QColor(255, 255, 255, 200))
        
        layout.addLayoutItem(north_arrow)
        
    def add_metadata(self, layout, results, aoi_geometry, sensors):
        """Add metadata panel"""
        metadata = QgsLayoutItemLabel(layout)
        metadata.attemptSetSceneRect(QRectF(10, 330, 280, 60))
        
        area_km2 = aoi_geometry.area() / 1000000
        
        meta_text = "<b>Analysis Metadata</b><br/>"
        meta_text += f"Area analyzed: {area_km2:.2f} km²<br/>"
        meta_text += f"Sensors used: {len(sensors)}<br/>"
        meta_text += f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}<br/>"
        meta_text += f"Processing: Google Earth Engine<br/>"
        meta_text += f"Plugin: GeoMiningOpt v1.0"
        
        metadata.setText(meta_text)
        metadata.setFont(QFont("Arial", 9))
        metadata.setBackgroundEnabled(True)
        metadata.setBackgroundColor(QColor(240, 240, 240))
        
        layout.addLayoutItem(metadata)
        
    def export_to_pdf(self, layout, output_path):
        """
        Export layout to PDF
        
        Args:
            layout: QgsPrintLayout
            output_path: str (path to output PDF)
        """
        exporter = QgsLayoutExporter(layout)
        
        settings = QgsLayoutExporter.PdfExportSettings()
        settings.dpi = 300
        settings.rasterizeWholeImage = False
        
        result = exporter.exportToPdf(output_path, settings)
        
        if result != QgsLayoutExporter.Success:
            raise Exception(f"Failed to export PDF: {result}")
            
        return output_path
