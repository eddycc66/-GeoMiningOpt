# GeoMiningOpt QGIS Plugin

## Descripción

GeoMiningOpt es un plugin profesional para QGIS que permite realizar exploración minera usando Google Earth Engine con soporte multi-sensor (Sentinel-2, Sentinel-1, Landsat 8/9). Optimizado para sistemas con recursos limitados mediante procesamiento server-side.

## Características

- ✅ **Multi-sensor**: Sentinel-2, Sentinel-1, Landsat 8, Landsat 9
- ✅ **Selección de fechas**: Rango configurable de fechas
- ✅ **AOI flexible**: Desde capa vectorial o dibujado manual
- ✅ **Clustering no supervisado**: K-means para detección de zonas mineralizadas
- ✅ **Índices espectrales**: NDVI, NDWI, ratios minerales, índices de textura
- ✅ **Mapas profesionales**: Escala, norte, leyenda, grid, metadatos
- ✅ **Exportación**: GeoTIFF y Shapefile a Google Drive
- ✅ **Optimizado**: Todo el procesamiento pesado en GEE (mínimo uso de RAM local)

## Requisitos

- QGIS >= 3.34
- Python 3.9+
- Cuenta de Google Earth Engine
- Librerías Python:
  - `earthengine-api`
  - `PyQt5`

## Instalación

### Método 1: Desde el repositorio de plugins de QGIS

1. Abrir QGIS
2. Ir a `Complementos` > `Administrar e instalar complementos`
3. Buscar "GeoMiningOpt"
4. Hacer clic en `Instalar complemento`

### Método 2: Instalación manual

1. Descargar el plugin
2. Copiar la carpeta `GeoMiningOpt` a:
   - **Windows**: `C:\Users\<usuario>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
   - **Linux**: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
   - **Mac**: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`

3. Reiniciar QGIS

4. Activar el plugin en `Complementos` > `Administrar e instalar complementos` > `Instalados`

### Instalación de dependencias

Si `earthengine-api` no está instalado:

```bash
# Desde OSGeo4W Shell (Windows) o terminal (Linux/Mac)
pip install earthengine-api
```

## Uso

### 1. Autenticación con Google Earth Engine

1. Abrir el plugin: `Complementos` > `GeoMiningOpt` > `Mineral Exploration (GEE)`
2. Hacer clic en `Authenticate`
3. Seguir las instrucciones en el navegador para autorizar el acceso
4. El estado cambiará a "✅ Authenticated"

### 2. Definir Área de Estudio (AOI)

**Opción A: Usar capa vectorial**
- Seleccionar `Use active layer`
- Elegir la capa del menú desplegable

**Opción B: Dibujar en el mapa**
- Seleccionar `Draw on canvas`
- Hacer clic en `Draw Rectangle`
- Dibujar el área en el mapa (clic izquierdo para añadir puntos, clic derecho para finalizar)

### 3. Configurar Parámetros

**Rango de fechas:**
- Seleccionar fecha de inicio y fin
- Por defecto: últimos 12 meses

**Sensores:**
- Marcar los sensores deseados:
  - ☑ Sentinel-2 (Optical)
  - ☑ Sentinel-1 (Radar)
  - ☑ Landsat 8
  - ☑ Landsat 9

**Parámetros de análisis:**
- **Número de clusters**: 3-20 (recomendado: 8)
- **Nubosidad máxima**: 0-100% (recomendado: 20%)
- **Resolución**: 10m, 30m o 60m (recomendado: 30m para balance velocidad/calidad)

### 4. Ejecutar Análisis

1. Hacer clic en `Run Analysis`
2. Esperar a que se complete el procesamiento (se muestra progreso)
3. Los resultados se exportarán automáticamente a Google Drive

### 5. Descargar Resultados

1. Ir a Google Drive > `GEE_Mineral_Exploration`
2. Descargar los archivos generados:
   - `mineral_clusters_*.tif` - Imagen clasificada por clusters
   - `mineral_probability_*.tif` - Mapa de probabilidad de mineralización
   - `rgb_composite_*.tif` - Composición RGB estándar
   - `mineral_zones_*.shp` - Polígonos de zonas mineralizadas

3. Cargar en QGIS usando `Capa` > `Añadir capa` > `Añadir capa ráster/vectorial`

### 6. Generar Mapa Profesional

1. Hacer clic en `Generate Map`
2. El plugin creará un layout profesional con:
   - Mapa principal
   - Escala
   - Flecha de norte
   - Leyenda
   - Título con metadatos
   - Grid de coordenadas

3. El mapa se exportará automáticamente a PDF en la carpeta de salida

## Interpretación de Resultados

### Clusters

Los clusters representan grupos espectrales similares. Para exploración mineral, buscar:

- **Clusters con alta reflectancia en SWIR** (B11, B12) → Posible alteración hidrotermal
- **Clusters con alto ratio Fe** (Red/Blue) → Óxidos de hierro
- **Clusters con bajo NDVI** → Poca vegetación (típico de zonas alteradas)

### Mapa de Probabilidad

- **Rojo/Naranja**: Alta probabilidad de mineralización
- **Amarillo**: Probabilidad media
- **Verde/Azul**: Baja probabilidad

### Polígonos Vectoriales

Cada polígono tiene atributos:
- `area_ha`: Área en hectáreas
- `area_m2`: Área en metros cuadrados

Priorizar polígonos grandes con alta probabilidad.

## Integración con Modelos Económicos

Los resultados del plugin pueden alimentar modelos de optimización económica tipo Hotelling:

1. **Estimación de reservas (Q₀)**:
   - Área mineralizada × espesor estimado × densidad × ley

2. **Estimación de costos**:
   - Zonas de alta probabilidad → menor costo de extracción
   - Topografía (del DEM) → tipo de minería (cielo abierto vs. subterránea)

3. **Secuenciación de extracción**:
   - Priorizar zonas con mayor anomalía y menor costo de acceso

## Solución de Problemas

### Error de autenticación

```
Error: Not authenticated with Google Earth Engine
```

**Solución**: Hacer clic en `Authenticate` y completar el proceso de autorización.

### Error: "No optical sensors selected"

**Solución**: Marcar al menos un sensor óptico (Sentinel-2, Landsat 8 o Landsat 9).

### Error: "No layer selected"

**Solución**: Si usa "Use active layer", asegurarse de que hay una capa vectorial seleccionada en el menú desplegable.

### Exportación lenta

**Solución**: 
- Reducir el área de estudio
- Aumentar la resolución (usar 60m en lugar de 10m)
- Reducir el rango de fechas

### Plugin no aparece en el menú

**Solución**:
1. Verificar que está en la carpeta correcta de plugins
2. Reiniciar QGIS
3. Activar en `Complementos` > `Administrar e instalar complementos` > `Instalados`

## Limitaciones

- Requiere conexión a internet para acceder a Google Earth Engine
- El procesamiento depende de la cuota de GEE (normalmente suficiente para uso académico)
- Áreas muy grandes (>10,000 km²) pueden tardar mucho en procesarse

## Créditos

- **Autor**: Edwin Condori
- **Email**: eddycc66@gmail.com
- **Versión**: 2.0.9
- **Licencia**: GPL v2+

## Referencias

- Google Earth Engine: https://earthengine.google.com/
- Sentinel-2: https://sentinel.esa.int/web/sentinel/missions/sentinel-2
- Sentinel-1: https://sentinel.esa.int/web/sentinel/missions/sentinel-1
- Landsat: https://landsat.gsfc.nasa.gov/

## Contribuir

Para reportar bugs o sugerir mejoras, por favor abrir un issue en:
https://github.com/yourusername/GeoMiningOpt/issues

## Changelog

### v2.0.9 (2026-01-06)
- Fix: Corrected RGB band names from generic 'Red/Green/Blue' to Sentinel-2 specific 'B4/B3/B2'.
- Success: Confirmed successful generation of Anomalies, Probability, and Vectors in v2.0.8.

### v2.0.8 (2026-01-06)
- Fix: Corrected indentation error in RGB download section invoked in the background thread.

### v2.0.7 (2026-01-06)
- Fix: Critical syntax error (IndentationError) caused by a stray `try` block in v2.0.6.

### v2.0.6 (2026-01-06)
- Feature: Added **Adaptive Resolution Logic**. If "User memory limit exceeded" occurs, the plugin automatically retries with a coarser resolution (2x, 4x, etc.) until it succeeds.
- Optimization: RGB Composite is now converted to 8-bit (visualize) before download, reducing file size by 75%.
- Resilience: Vectorization now also includes adaptive retry logic.

### v2.0.5 (2026-01-06)
- Fix: Confirmed replacement of legacy `vectorize_clusters` with `vectorize_anomalies`.
- Optimization: Reduced memory load by using 500m scale for global statistics (Z-Score baseline).
- Optimization: Excluded texture bands from anomaly calculation graph to save RAM.

### v2.0.4 (2026-01-06)
- Performace: Increased `tileScale=16` for maximum memory resilience.
- Debug: Added startup verification log to confirm correct version loading.

### v2.0.3 (2026-01-06)
- Stability: Added thread-safe `ee.Initialize()` in background worker and disabled strict SSL verification to prevent QGIS "Access Violation" crashes on Windows.

### v2.0.2 (2026-01-06)
- Performace: Added `tileScale=4` to Anomaly Detection. This effectively quadruples the available memory for statistical calculations, solving "User memory limit exceeded" on 100m stats.

### v2.0.1 (2026-01-06)
- Fix: Added missing `vectorize_anomalies` method to GEEProcessor class that caused AttributeError.

### v2.0.0 (2026-01-06) MAJOR UPDATE
- Algorithm: REPLACED K-Means Clustering with **Statistical Anomaly Detection (Z-Score)**.
  - Now produces precise "Target Polygons" (red) instead of generic zones.
  - Automatically adapts to the background geology of the specific AOI.
  - Vectorization enabled at high resolution (20-30m) because only anomalies are exported.

### v1.1.7 (2026-01-06)
- Performace: Implemented "Adaptive Resolution". If 10m fails, it auto-retries at 20m/40m to guarantee map delivery.
- Stability: Increased download timeout to 20 minutes (1200s).

### v1.1.6 (2026-01-06)
- Performace: Redesigned calculation engine (Split-Reduce) -> 90% less memory usage
- Fix: Forced vectors to 100m scale to ensure download success

### v1.1.5 (2026-01-06)
- Performace: Optimized K-Means training (using 100m scale) to fix "User memory limit exceeded"
- Performace: Converted Probability map to 8-bit (Byte) for 4x faster and lighter download

### v1.1.4 (2026-01-06)
- Stabilize: Clean rewrite of result handling logic to prevent load errors

### v1.1.3 (2026-01-06)
- Fix: Removed heavy GLCM Texture analysis to solve "User memory limit exceeded"
- Fix: Fixed vector download format error ("dict has no attribute upper")

### v1.1.2 (2026-01-06)
- Fix: Resolved IndentationError in dialogue preventing plugin load

### v1.1.1 (2026-01-06)
- Debug: Added detailed error reporting for failed downloads (no more silent failures)
- UX: Improved success/failure messages with specific error logs

### v1.1.0 (2026-01-06)
- Fix: Fixed "Invalid value... JSON" error by using `GEO_JSON` format
- Performance: Optimized RGB download (4x faster) by converting to 8-bit on server
- Stability: Added error skip to allow partial results if one download fails

### v1.0.9 (2026-01-06)
- Improvement: Real-time progress bar during download steps
- UX: User can now see bytes downloading instead of static "Downloading..." state

### v1.0.8 (2026-01-06)
- Fix: Fixed "aoi_json is not defined" error in analysis setup

### v1.0.7 (2026-01-06)
- Fix: Fixed plugin loading error (AttributeError: 'NoneType')
- Refactor: Moved background task logic to separate module for better stability

### v1.0.6 (2026-01-06)
- Fix: Resolved Python Thread Error by decoupling QGIS Geometry from background task
- Stability: Improved thread safety during analysis

### v1.0.5 (2026-01-06)
- Major: Implemented background processing using `QgsTask` to prevent GUI freezing
- Fix: Added timeout (10 min) to download requests
- Improvement: Result files are downloaded asynchronously

### v1.0.4 (2026-01-06)
- Fix: Added explicit Float casting to prevent "heterogeneous image collection" errors
- Improvement: Better compatibility when merging Sentinel-2 and Landsat data

### v1.0.3 (2026-01-06)
- Major: Changed from Google Drive export to direct local download
- Fix: Resolved `QgsLayoutItemPage` error in map generation
- Feature: Results now saved immediately to local output folder

### v1.0.2 (2026-01-06)
- Fix: Removing hardcoded project ID to allow user default authentication
- Feature: Display GEE Task IDs in success message
- Fix: Improved error handling for export tasks

### v1.0.1 (2026-01-06)
- Removida mejora S2DR3 para evitar errores de Reducer
- Uso de imágenes Sentinel-2 estándar sin super-resolución
- Añadidos índices de textura simplificados (brightness, greenness, wetness)
- Corrección de errores en procesamiento GEE

### v1.0.0 (2026-01-06)
- Lanzamiento inicial
- Soporte multi-sensor (Sentinel-2, Sentinel-1, Landsat 8/9)
- Clustering K-means no supervisado
- Generación de mapas profesionales
- Exportación a Google Drive
