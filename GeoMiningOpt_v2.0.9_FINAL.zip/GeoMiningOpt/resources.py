# -*- coding: utf-8 -*-

# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 5.15.2
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore

qt_resource_data = b"\
\x00\x00\x00\x00\
"

qt_resource_name = b"\
\x00\x07\
\x07\x3b\xe0\xb3\
\x00p\
\x00l\x00u\x00g\x00i\x00n\x00s\
\x00\x0f\
\x0f\x0e\x6a\xa3\
\x00g\
\x00e\x00o\x00m\x00i\x00n\x00i\x00n\x00g\x00_\x00o\x00p\x00t\
\x00\x08\
\x0a\x61\x5a\xa7\
\x00i\
\x00c\x00o\x00n\x00.\x00p\x00n\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x1e\x00\x02\x00\x00\x00\x01\x00\x00\x00\x03\
\x00\x00\x00\x3e\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
