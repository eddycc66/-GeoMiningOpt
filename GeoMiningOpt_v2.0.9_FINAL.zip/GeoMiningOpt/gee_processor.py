# -*- coding: utf-8 -*-
"""
/***************************************************************************
 GEE Processor
 Google Earth Engine processing module for mineral exploration
                              -------------------
        begin                : 2026-01-06
        copyright            : (C) 2026 by Edwin Condori
        email                : eddycc66@gmail.com
 ***************************************************************************/
"""

import ee
import os
import requests
import zipfile
import io
import json
from datetime import datetime


class GEEProcessor:
    """
    Google Earth Engine processor for mineral exploration.
    
    All heavy processing is done server-side on GEE to minimize local memory usage.
    Supports multiple sensors: Sentinel-2, Sentinel-1, Landsat 8/9
    """
    
    def __init__(self):
        """Initialize GEE processor"""
        print("DEBUG: GeoMiningOpt GEEProcessor v2.0.4 INITIALIZED")
        self.project_id = None # Use default project
        self.authenticated = False
        
    def check_authentication(self):
        """Check if already authenticated"""
        try:
            ee.Initialize()
            self.authenticated = True
            return True
        except:
            return False
            
    def authenticate(self):
        """Authenticate with Google Earth Engine"""
        try:
            ee.Authenticate()
            ee.Initialize()
            self.authenticated = True
            return True
        except Exception as e:
            print(f"Authentication error: {e}")
            return False
            
    def qgis_geometry_to_ee(self, qgis_geom):
        """
        Convert QGIS geometry to Earth Engine geometry
        
        Args:
            qgis_geom: QgsGeometry in WGS84
            
        Returns:
            ee.Geometry
        """
        if isinstance(qgis_geom, str):
            geom_json = qgis_geom
        else:
            # Assume it's a QgsGeometry if not string
            geom_json = qgis_geom.asJson()
            
        import json
        geom_dict = json.loads(geom_json)
        
        # Convert to EE geometry
        if geom_dict['type'] == 'Polygon':
            coords = geom_dict['coordinates']
            return ee.Geometry.Polygon(coords)
        elif geom_dict['type'] == 'MultiPolygon':
            coords = geom_dict['coordinates']
            return ee.Geometry.MultiPolygon(coords)
        else:
            raise ValueError(f"Unsupported geometry type: {geom_dict['type']}")
            
    def get_sentinel2_collection(self, aoi, start_date, end_date, cloud_cover):
        """
        Get Sentinel-2 Surface Reflectance collection
        
        Args:
            aoi: ee.Geometry
            start_date: str (YYYY-MM-DD)
            end_date: str (YYYY-MM-DD)
            cloud_cover: int (max cloud cover percentage)
            
        Returns:
            ee.ImageCollection
        """
        def mask_s2_clouds(image):
            """Mask clouds using QA60 band"""
            qa = image.select('QA60')
            cloud_bit_mask = 1 << 10
            cirrus_bit_mask = 1 << 11
            mask = qa.bitwiseAnd(cloud_bit_mask).eq(0).And(
                   qa.bitwiseAnd(cirrus_bit_mask).eq(0))
            return image.updateMask(mask).divide(10000).toFloat()
        
        collection = (ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
            .filterBounds(aoi)
            .filterDate(start_date, end_date)
            .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', cloud_cover))
            .map(mask_s2_clouds)
            .select(['B2', 'B3', 'B4', 'B8', 'B11', 'B12']))
            
        return collection
        
    def get_sentinel1_collection(self, aoi, start_date, end_date):
        """
        Get Sentinel-1 GRD collection
        
        Args:
            aoi: ee.Geometry
            start_date: str (YYYY-MM-DD)
            end_date: str (YYYY-MM-DD)
            
        Returns:
            ee.ImageCollection
        """
        collection = (ee.ImageCollection('COPERNICUS/S1_GRD')
            .filterBounds(aoi)
            .filterDate(start_date, end_date)
            .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
            .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
            .filter(ee.Filter.eq('instrumentMode', 'IW'))
            .select(['VV', 'VH']))
            
        return collection
        
    def get_landsat8_collection(self, aoi, start_date, end_date, cloud_cover):
        """
        Get Landsat 8 Surface Reflectance collection
        
        Args:
            aoi: ee.Geometry
            start_date: str (YYYY-MM-DD)
            end_date: str (YYYY-MM-DD)
            cloud_cover: int (max cloud cover percentage)
            
        Returns:
            ee.ImageCollection
        """
        def mask_landsat_clouds(image):
            """Mask clouds using QA_PIXEL band"""
            qa = image.select('QA_PIXEL')
            # Bits 3 and 4 are cloud and cloud shadow
            cloud_mask = qa.bitwiseAnd(1 << 3).eq(0).And(
                        qa.bitwiseAnd(1 << 4).eq(0))
            return (image.updateMask(cloud_mask)
                   .multiply(0.0000275).add(-0.2)  # Scale factors
                   .select(['SR_B2', 'SR_B3', 'SR_B4', 'SR_B5', 'SR_B6', 'SR_B7'],
                          ['B2', 'B3', 'B4', 'B8', 'B11', 'B12'])  # Rename to match S2
                   .toFloat())
        
        collection = (ee.ImageCollection('LANDSAT/LC08/C02/T1_L2')
            .filterBounds(aoi)
            .filterDate(start_date, end_date)
            .filter(ee.Filter.lt('CLOUD_COVER', cloud_cover))
            .map(mask_landsat_clouds))
            
        return collection
        
    def get_landsat9_collection(self, aoi, start_date, end_date, cloud_cover):
        """
        Get Landsat 9 Surface Reflectance collection
        
        Args:
            aoi: ee.Geometry
            start_date: str (YYYY-MM-DD)
            end_date: str (YYYY-MM-DD)
            cloud_cover: int (max cloud cover percentage)
            
        Returns:
            ee.ImageCollection
        """
        def mask_landsat_clouds(image):
            """Mask clouds using QA_PIXEL band"""
            qa = image.select('QA_PIXEL')
            cloud_mask = qa.bitwiseAnd(1 << 3).eq(0).And(
                        qa.bitwiseAnd(1 << 4).eq(0))
            return (image.updateMask(cloud_mask)
                   .multiply(0.0000275).add(-0.2)
                   .select(['SR_B2', 'SR_B3', 'SR_B4', 'SR_B5', 'SR_B6', 'SR_B7'],
                          ['B2', 'B3', 'B4', 'B8', 'B11', 'B12'])
                   .toFloat())
        
        collection = (ee.ImageCollection('LANDSAT/LC09/C02/T1_L2')
            .filterBounds(aoi)
            .filterDate(start_date, end_date)
            .filter(ee.Filter.lt('CLOUD_COVER', cloud_cover))
            .map(mask_landsat_clouds))
            
        return collection
        
    def calculate_spectral_indices(self, image):
        """
        Calculate spectral indices for mineral exploration
        
        Args:
            image: ee.Image with bands B2, B3, B4, B8, B11, B12
            
        Returns:
            ee.Image with additional index bands
        """
        # NDVI: (NIR - Red) / (NIR + Red)
        ndvi = image.normalizedDifference(['B8', 'B4']).rename('NDVI')
        
        # NDWI: (Green - NIR) / (Green + NIR)
        ndwi = image.normalizedDifference(['B3', 'B8']).rename('NDWI')
        
        # Clay Minerals Ratio (SWIR1/SWIR2)
        clay = image.select('B11').divide(image.select('B12')).rename('CLAY_RATIO')
        
        # Iron Oxide Ratio (Red/Blue)
        iron = image.select('B4').divide(image.select('B2')).rename('IRON_RATIO')
        
        # Ferrous Minerals Ratio (SWIR2/NIR)
        ferrous = image.select('B12').divide(image.select('B8')).rename('FERROUS_RATIO')
        
        return image.addBands([ndvi, ndwi, clay, iron, ferrous])
        
    def add_texture_indices(self, image):
        """
        Add simple texture and composite indices for mineral exploration
        
        This adds basic spectral transformations without complex enhancement:
        - Brightness index (average of all bands)
        - Greenness index (vegetation indicator)
        - Wetness index (moisture indicator)
        
        Args:
            image: ee.Image with bands B2, B3, B4, B8, B11, B12
            
        Returns:
            ee.Image with additional texture bands
        """
        # Create brightness index (average of all bands)
        brightness = (image.select('B2').add(image.select('B3'))
                     .add(image.select('B4')).add(image.select('B8'))
                     .add(image.select('B11')).add(image.select('B12'))
                     .divide(6.0).rename('BRIGHTNESS'))
        
        # Create greenness index (vegetation component)
        greenness = (image.select('B8').subtract(image.select('B4'))
                    .divide(image.select('B8').add(image.select('B4')).add(0.0001))
                    .rename('GREENNESS'))
        
        # Create wetness index (moisture component)
        wetness = (image.select('B3').subtract(image.select('B12'))
                  .divide(image.select('B3').add(image.select('B12')).add(0.0001))
                  .rename('WETNESS'))
        
        # Add all texture bands
        return image.addBands([brightness, greenness, wetness])

        
    def detect_anomalies(self, image, aoi, scale, threshold_sigma=2.0):
        """
        Detect Mineral Anomalies using Statistical Thresholding (Z-Score)
        Instead of clustering everything, we find pixels derived from Clay/Iron/Ferrous 
        that are significantly higher than the background average.
        
        Args:
            image: ee.Image with spectral indices
            aoi: ee.Geometry
            scale: int (resolution in meters)
            threshold_sigma: float (std deviations above mean to consider anomalous)
            
        Returns:
            ee.Image (binary mask of anomalies, where 1=Anomaly, 0=Background)
        """
        # Select key mineral indices
        indices = image.select(['CLAY_RATIO', 'IRON_RATIO', 'FERROUS_RATIO', 'NDWI'])
        
        # 1. Calculate Statistics over the AOI
        # We use a coarser scale (100m) for stats to avoid memory limits, applied to finer pixels
        stats = indices.reduceRegion(
            reducer=ee.Reducer.mean().combine(
                reducer2=ee.Reducer.stdDev(),
                sharedInputs=True
            ),
            geometry=aoi,
            scale=max(scale, 500), # 500m for global stats to save memory
            bestEffort=True,
            tileScale=16, # ULTRA Optimize memory (4x -> 16x)
            maxPixels=1e9
        )
        
        # 2. Compute Z-Scores: (Pixel - Mean) / StdDev
        # We do this for each band
        def get_z_score(band_name):
            mean = ee.Number(stats.get(f'{band_name}_mean'))
            std = ee.Number(stats.get(f'{band_name}_stdDev'))
            # Avoid division by zero
            return image.select(band_name).subtract(mean).divide(std).rename(f'{band_name}_Z')
            
        z_clay = get_z_score('CLAY_RATIO')
        z_iron = get_z_score('IRON_RATIO')
        z_ferrous = get_z_score('FERROUS_RATIO')
        
        # 3. Define Anomalies
        # Anomaly = (Clay_Z > Threshold OR Iron_Z > Threshold) AND Not Water (NDWI < 0)
        # We focus on Clay/Iron as primary indicators.
        
        is_anomaly = (z_clay.gt(threshold_sigma)
                      .Or(z_iron.gt(threshold_sigma))
                      .And(image.select('NDWI').lt(0))) # Exclude water bodies
        
        # Clean up noise: use focal mode to remove single pixel speckles
        is_anomaly_clean = is_anomaly.focal_mode(1, 'square', 'pixels')
        
        return is_anomaly_clean.rename('ANOMALY').toByte()
        
    def calculate_mineral_probability(self, image):
        """
        Calculate mineral probability based on spectral characteristics
        
        Args:
            image: ee.Image with spectral indices
            
        Returns:
            ee.Image (probability map)
        """
        prob = (image.select('IRON_RATIO').unitScale(0.8, 1.5).multiply(0.3)
               .add(image.select('CLAY_RATIO').unitScale(0.9, 1.2).multiply(0.25))
               .add(image.select('NDVI').multiply(-1).unitScale(-0.5, 0.2).multiply(0.2))
               .add(image.select('B12').unitScale(0.1, 0.4).multiply(0.25))
               .rename('PROB_MINERAL'))
        
        return prob
        
    def vectorize_anomalies(self, anomaly_image, name, folder_path, aoi, scale, progress_callback=None, progress_range=None):
        """
        Vectorize ONLY the anomalies (pixel value = 1)
        """
        # Vectorize
        # Since anomaly_image is sparse, we can try using the requested scale (e.g. 30m).
        # We start with scale, but cap min at 20m.
        
        current_scale = max(scale, 20)
        max_retries = 3
        vectors = None
        
        for attempt in range(max_retries):
            try:
                print(f"Vectorizing anomalies attempt {attempt+1} at {current_scale}m")
                vectors = anomaly_image.updateMask(anomaly_image.eq(1)).reduceToVectors(
                    geometry=aoi,
                    scale=current_scale,
                    geometryType='polygon',
                    eightConnected=False,
                    labelProperty='anomaly_class',
                    reducer=ee.Reducer.countEvery(),
                    maxPixels=1e9,
                    bestEffort=True,
                    tileScale=4 # Add tileScale here too!
                )
                
                # Force an info call? No, that triggers download.
                # reduceToVectors is lazy. The error happens at download time.
                # So we must return the lazy object, BUT download_vectors_to_local will trigger it.
                # We need to wrap the DOWNLOAD call in the retry loop.
                # But wait, reduceToVectors is creating the FEATURE COLLECTION.
                # If download fails, we need to Re-Run reduceToVectors with a new scale.
                
                # So we can't just return 'vectors'. We must try to download it INSIDE this loop.
                # Use a flag "is_last_attempt" to re-raise error?
                
                # Let's break the pattern: call download directly here to catch error.
                return self.download_vectors_to_local(vectors, name, folder_path, progress_callback, progress_range)
                
            except Exception as e:
                print(f"Vectorization failed at {current_scale}m: {e}")
                if attempt < max_retries - 1:
                    current_scale = current_scale * 2
                else:
                    raise e
                    
        return None # Should not reach here
        
    def download_image_to_local(self, image, name, folder_path, aoi, scale, progress_callback=None, progress_range=None):
        """
        Download image directly to local storage with progress reporting
        """
        # Define output path
        out_file = os.path.join(folder_path, f"{name}.tif")
        
        current_scale = scale
        max_retries = 3
        
        for attempt in range(max_retries):
            try:
                print(f"Attempt {attempt+1}/{max_retries} for {name} at scale {current_scale}m")
                
                # Get download URL
                url = image.getDownloadURL({
                    'scale': current_scale,
                    'crs': 'EPSG:4326',
                    'region': aoi,
                    'filePerBand': False,
                    'format': 'GEO_TIFF'
                })
                
                print(f"Downloading {name} from {url}...")
                
                # Download
                # VERIFY=FALSE is critical for QGIS Windows stability
                response = requests.get(url, stream=True, timeout=600, verify=False)
                
                if response.status_code == 200:
                    total_size = int(response.headers.get('content-length', 0))
                    block_size = 1024 * 1024 # 1MB chunk
                    wrote = 0
                    
                    # Handle ZIP or direct file
                    is_zip = 'application/zip' in response.headers.get('Content-Type', '')
                    
                    save_path = out_file
                    if is_zip:
                        save_path = os.path.join(folder_path, f"{name}.zip")
    
                    with open(save_path, 'wb') as f:
                        for data in response.iter_content(block_size):
                            wrote += len(data)
                            f.write(data)
                            
                            if progress_callback and progress_range and total_size > 0:
                                # Calculate local percent 0-1
                                local_pct = wrote / total_size
                                # Map to global range
                                start, end = progress_range
                                global_pct = start + (local_pct * (end - start))
                                progress_callback(global_pct)
                    
                    if is_zip:
                        with zipfile.ZipFile(save_path, 'r') as z:
                             z.extractall(folder_path)
                        os.remove(save_path) # Clean up zip
                        # Try to find the extracted tif
                        potential_files = [f for f in os.listdir(folder_path) if f.endswith('.tif') and name in f]
                        if potential_files:
                           return os.path.join(folder_path, potential_files[0])
                    
                    print(f"Saved to {out_file}")
                    return out_file
                else:
                    # If GEE returns error in body (e.g. 400 Bad Request)
                    err_msg = response.text
                    if "User memory limit exceeded" in err_msg or "size" in err_msg:
                        raise Exception(f"Memory Limit: {err_msg}")
                    else:
                        raise Exception(f"Failed to download image: {err_msg}")
                    
            except Exception as e:
                print(f"Error downloading {name} at {current_scale}m: {e}")
                
                # Only retry if it looks like a memory/timeout issue
                if attempt < max_retries - 1:
                    current_scale = current_scale * 2
                    print(f"Retrying with coarser resolution: {current_scale}m...")
                    continue
                else:
                    # Final failure
                    raise e

    def download_vectors_to_local(self, vectors, name, folder_path, progress_callback=None, progress_range=None):
        """
        Download vectors to local storage (GeoJSON) with progress
        """
        out_file = os.path.join(folder_path, f"{name}.geojson")
        
        try:
            url = vectors.getDownloadURL('geojson')
            
            print(f"Downloading vectors {name}...")
            response = requests.get(url, stream=True, timeout=600)
            
            if response.status_code == 200:
                total_size = int(response.headers.get('content-length', 0))
                block_size = 1024 * 1024
                wrote = 0
                
                with open(out_file, 'wb') as f:
                    for data in response.iter_content(block_size):
                        wrote += len(data)
                        f.write(data)
                        
                        if progress_callback and progress_range and total_size > 0:
                            local_pct = wrote / total_size
                            start, end = progress_range
                            global_pct = start + (local_pct * (end - start))
                            progress_callback(global_pct)
                            
                print(f"Saved to {out_file}")
                return out_file
            else:
                raise Exception(f"Failed to download vectors: {response.text}")
                
        except Exception as e:
            print(f"Error downloading vectors {name}: {e}")
            raise e
        
    def run_analysis(self, aoi_geometry, sensors, start_date, end_date, 
                     num_clusters, cloud_cover, resolution, output_folder, progress_callback=None):
        """
        Run complete mineral exploration analysis and save locally
        
        Args:
            output_folder: str (Local path to save files)
            ...
        """
        if not self.authenticated:
            # Try to re-initialize in this thread context just in case
            try:
                ee.Initialize()
                self.authenticated = True
            except:
                raise Exception("Not authenticated with Google Earth Engine")

        # Force re-initialization in the worker thread to prevent context issues
        try:
             ee.Initialize()
        except:
             pass
             
        # Suppress SSL warnings for stability
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
             
        # Ensure output folder exists
        os.makedirs(output_folder, exist_ok=True)
        
        # Convert AOI to EE geometry
        aoi = self.qgis_geometry_to_ee(aoi_geometry)
        
        if progress_callback:
            progress_callback(15)
        
        # Collect data from sensors (Logic unchanged)
        # ... (Sensor collection logic remains the same, skipping lines for brevity) ...
        # NOTE: WE MUST REPEAT THE LOGIC HERE OR CAREFULLY EDIT. 
        # Since replace_file_content replaces a block, I will include the core logic and just change the export part.
        
        # ... Re-implementing the core logic to be safe ...
        
        collections = []
        if 'sentinel2' in sensors:
            collections.append(self.get_sentinel2_collection(aoi, start_date, end_date, cloud_cover))
        if 'landsat8' in sensors:
            collections.append(self.get_landsat8_collection(aoi, start_date, end_date, cloud_cover))
        if 'landsat9' in sensors:
            collections.append(self.get_landsat9_collection(aoi, start_date, end_date, cloud_cover))
            
        if not collections:
            raise ValueError("No sensors selected")
            
        if progress_callback: progress_callback(30)
        
        # Merge
        merged_optical = ee.ImageCollection(collections[0])
        for col in collections[1:]:
            merged_optical = merged_optical.merge(col)
        optical_composite = merged_optical.median().clip(aoi)
        
        if progress_callback: progress_callback(40)
        
        # Indices
        optical_with_indices = self.calculate_spectral_indices(optical_composite)
        
        # Radar
        if 'sentinel1' in sensors:
            s1_col = self.get_sentinel1_collection(aoi, start_date, end_date)
            s1_composite = s1_col.median().clip(aoi)
            vv_vh_ratio = s1_composite.select('VV').divide(s1_composite.select('VH')).rename('VV_VH_RATIO')
            s1_composite = s1_composite.addBands(vv_vh_ratio)
            stack = optical_with_indices.addBands(s1_composite)
        else:
            stack = optical_with_indices
            
        if progress_callback: progress_callback(50)
        
        # Texture
        stack_with_texture = self.add_texture_indices(stack)
        
        # Probability
        prob_mineral = self.calculate_mineral_probability(stack_with_texture)
        
        if progress_callback: progress_callback(60)
        
        # 1. ANOMALY DETECTION (New v2.0.0)
        # Calculate statistical anomalies (Z-Score > 2)
        # Verify if 'stack' has the required indices (CLAY_RATIO, etc). 
        # Yes, calculate_spectral_indices adds them to 'stack' (via optical_with_indices).
        # We use 'stack' (lighter) instead of 'stack_with_texture' to avoid computing unused texture bands during stats.
        anomalies = self.detect_anomalies(stack, aoi, resolution, threshold_sigma=2.0)
        
        if progress_callback: progress_callback(70)
        
        # 2. Vectorize ONLY Anomalies (and download immediately)
        # This returns the path to the downloaded GeoJSON
        try:
             # We perform vector download early to fail fast if geometry is an issue, 
             # but to keep order consistent with previous logic, we can just assign it to a var 
             # and add to dict later. However, since vectorize_anomalies performs download,
             # we should probably do it in the export section or here. 
             # For simpler flow, we'll keep the call here but store the result.
             # Actually, let's defer it to the export section to avoid multiple progress bar jumps.
             pass
        except:
             pass

        if progress_callback: progress_callback(80)
        
        # LOCAL DOWNLOAD EXPORT
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        downloaded_files = {}
        errors = []
        
        # 3. Download Anomaly Map (Binary)
        try:
            f1 = self.download_image_to_local(
                anomalies, f'mineral_anomalies_{timestamp}', output_folder, aoi, resolution,
                progress_callback, (50, 65)
            )
            downloaded_files['anomalies'] = f1
        except Exception as e:
            msg = f"Skipping anomalies: {e}"
            print(msg)
            errors.append(msg)
        
        if progress_callback: progress_callback(65)
        
        # 2. Download Probability Map (65-80%)
        try:
            # Optimize: Convert probability (0-1 float) to percentage (0-100 byte)
            prob_byte = prob_mineral.multiply(100).toByte()
            
            f2 = self.download_image_to_local(
                prob_byte, f'mineral_probability_{timestamp}', output_folder, aoi, resolution,
                progress_callback, (65, 80)
            )
            downloaded_files['probability'] = f2
        except Exception as e:
            msg = f"Skipping probability: {e}"
            print(msg)
            errors.append(msg)
            
        if progress_callback: progress_callback(80)
        
        # 3. Download RGB (80-95%) - OPTIMIZED to 8-bit
        try:
            # Visualize on server-side to reduce size (Float32 -> uint8 is 4x smaller)
            rgb_visualized = stack_with_texture.visualize(
                bands=['B4', 'B3', 'B2'],
                min=0,
                max=0.3
            )
            
            f3 = self.download_image_to_local(
                rgb_visualized, f'rgb_composite_{timestamp}', output_folder, aoi, resolution, 
                progress_callback, (85, 100)
            )
            downloaded_files['start_rgb'] = f3
        except Exception as e:
            msg = f"Skipping RGB: {e}"
            print(msg)
            errors.append(msg)
            
        if progress_callback: progress_callback(95)
        
        # 4. Download Vectors (Anomalies Only)
        try:
            f4 = self.vectorize_anomalies(
                anomalies, f'mineral_targets_{timestamp}', output_folder, aoi, resolution,
                 progress_callback, (95, 100)
            )
            downloaded_files['vectors'] = f4
        except Exception as e:
            msg = f"Skipping vectors: {e}"
            print(msg)
            errors.append(msg)
        
        if progress_callback:
            progress_callback(100)
            
        return {
            'files': downloaded_files,
            'errors': errors,
            'timestamp': timestamp
        }
