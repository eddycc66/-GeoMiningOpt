# -*- coding: utf-8 -*-
from qgis.core import QgsTask, QgsMessageLog, Qgis

class AnalysisTask(QgsTask):
    """Background task for GEE Analysis"""
    
    def __init__(self, processor, aoi, sensors, start, end, clusters, cloud, res, folder):
        super().__init__("GeoMining Analysis", QgsTask.CanCancel)
        self.processor = processor
        self.aoi = aoi
        self.sensors = sensors
        self.start = start
        self.end = end
        self.clusters = clusters
        self.cloud = cloud
        self.res = res
        self.folder = folder
        self.results = None
        self.exception = None
        
    def run(self):
        """Run analysis in background thread"""
        try:
            QgsMessageLog.logMessage("Starting GEE background task", "GeoMiningOpt", Qgis.Info)
            
            # Wrapper to update task progress
            def update_progress(p):
                self.setProgress(p)
            
            # Since we cannot update GUI from here, we rely on final result
            self.results = self.processor.run_analysis(
                self.aoi, self.sensors, self.start, self.end,
                self.clusters, self.cloud, self.res, self.folder,
                progress_callback=update_progress 
            )
            return True
        except Exception as e:
            self.exception = e
            QgsMessageLog.logMessage(f"Task failed: {e}", "GeoMiningOpt", Qgis.Critical)
            return False

    def finished(self, result):
        """Called on main thread when done"""
        pass # Logic handled via signal connection in dialog
