# GeoMiningOpt Plugin Installation Guide

## Quick Installation

### Step 1: Copy Plugin Folder

Copy the entire `GeoMiningOpt` folder to your QGIS plugins directory:

**Windows:**
```
C:\Users\<your_username>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\
```

**Linux:**
```
~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/
```

**Mac:**
```
~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/
```

### Step 2: Install Dependencies

Open OSGeo4W Shell (Windows) or terminal (Linux/Mac) and run:

```bash
pip install earthengine-api
```

### Step 3: Compile Resources (Optional)

If you modify the UI or resources, recompile:

```bash
cd "path/to/GeoMiningOpt"
pyrcc5 resources.qrc -o resources.py
```

### Step 4: Restart QGIS

1. Close QGIS completely
2. Reopen QGIS

### Step 5: Enable Plugin

1. Go to `Plugins` > `Manage and Install Plugins`
2. Click on `Installed` tab
3. Find `GeoMiningOpt` and check the box to enable it

### Step 6: Access Plugin

The plugin will appear in:
- Menu: `Plugins` > `GeoMiningOpt` > `Mineral Exploration (GEE)`
- Toolbar: Look for the plugin icon

## First Use

1. Click the plugin icon or menu item
2. Click `Authenticate` to connect to Google Earth Engine
3. Follow the browser prompts to authorize
4. Start analyzing!

## Troubleshooting

### Plugin doesn't appear

- Check that the folder is in the correct location
- Restart QGIS
- Check QGIS Python console for errors: `Plugins` > `Python Console`

### Import errors

Make sure `earthengine-api` is installed:

```bash
pip list | grep earthengine
```

If not found, install it:

```bash
pip install earthengine-api
```

### UI doesn't load

Recompile the UI file:

```bash
pyuic5 geomining_dialog_base.ui -o geomining_dialog_base_ui.py
```

## File Structure

```
GeoMiningOpt/
├── __init__.py                    # Plugin initialization
├── metadata.txt                   # Plugin metadata
├── geomining_opt.py              # Main plugin class
├── geomining_dialog.py           # Dialog logic
├── geomining_dialog_base.ui      # Qt Designer UI file
├── gee_processor.py              # Google Earth Engine processor
├── map_composer.py               # Professional map generator
├── resources.qrc                 # Qt resources definition
├── resources.py                  # Compiled resources
├── icon.png                      # Plugin icon
└── README.md                     # User documentation
```

## Support

For issues or questions:
- Email: eddycc66@gmail.com
- GitHub: https://github.com/yourusername/GeoMiningOpt/issues
