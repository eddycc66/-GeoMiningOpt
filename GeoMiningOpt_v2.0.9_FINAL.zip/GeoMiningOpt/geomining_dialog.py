# -*- coding: utf-8 -*-
"""
/***************************************************************************
 GeoMiningOptDialog
                                 A QGIS plugin
 Mineral exploration using Google Earth Engine
                             -------------------
        begin                : 2026-01-06
        git sha              : $Format:%H$
        copyright            : (C) 2026 by Edwin Condori
        email                : eddycc66@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
from datetime import datetime, timedelta

from qgis.PyQt import uic
from qgis.PyQt.QtCore import pyqtSignal, QDate, Qt
from qgis.PyQt.QtWidgets import (QDialog, QMessageBox, QFileDialog, 
                                  QProgressDialog, QApplication)
from qgis.PyQt.QtGui import QColor
from qgis.core import (QgsProject, QgsVectorLayer, QgsRasterLayer, QgsApplication, QgsTask,
                        QgsMessageLog, Qgis, QgsMapLayerProxyModel,
                        QgsGeometry, QgsCoordinateReferenceSystem,
                        QgsCoordinateTransform, QgsWkbTypes)
from qgis.gui import QgsMapToolEmitPoint, QgsRubberBand

# Import GEE processor
from .gee_processor import GEEProcessor
from .map_composer import MapComposer
from .analysis_task import AnalysisTask

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'geomining_dialog_base.ui'))


class GeoMiningOptDialog(QDialog, FORM_CLASS):
    """Dialog for GeoMiningOpt plugin"""
    
    closingPlugin = pyqtSignal()

    def __init__(self, iface, parent=None):
        """Constructor."""
        super(GeoMiningOptDialog, self).__init__(parent)
        # Set up the user interface from Designer through FORM_CLASS.
        # After self.setupUi() you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)
        
        self.iface = iface
        self.gee_processor = GEEProcessor()
        self.map_composer = MapComposer(iface)
        
        # Authentication status
        self.is_authenticated = False
        
        # AOI drawing tool
        self.draw_tool = None
        self.rubber_band = None
        self.aoi_geometry = None
        
        # Results storage
        self.results = {}
        
        # Background task
        self.task = None
        
        # Setup UI components
        self.setup_ui()
        self.connect_signals()
        
    def setup_ui(self):
        """Setup UI components"""
        
        # Set default dates (last 12 months)
        end_date = QDate.currentDate()
        start_date = end_date.addMonths(-12)
        self.dateEdit_start.setDate(start_date)
        self.dateEdit_end.setDate(end_date)
        
        # Set date limits
        self.dateEdit_start.setMaximumDate(end_date)
        self.dateEdit_end.setMaximumDate(end_date)
        
        # Setup layer combo
        self.mMapLayerComboBox.setFilters(QgsMapLayerProxyModel.VectorLayer)
        
        # Set default values
        self.spinBox_clusters.setValue(8)
        self.spinBox_cloudcover.setValue(20)
        self.comboBox_resolution.setCurrentText("30")
        
        # Check all sensors by default
        self.checkBox_sentinel2.setChecked(True)
        self.checkBox_sentinel1.setChecked(True)
        self.checkBox_landsat8.setChecked(True)
        self.checkBox_landsat9.setChecked(True)
        
        # Professional map enabled by default
        self.checkBox_professionalMap.setChecked(True)
        
        # Set output folder to user's home
        self.lineEdit_outputFolder.setText(os.path.expanduser("~/GeoMiningOpt_Output"))
        
        # Update authentication status
        self.update_auth_status()
        
    def connect_signals(self):
        """Connect UI signals to slots"""
        
        # Authentication
        self.pushButton_authenticate.clicked.connect(self.authenticate_gee)
        
        # AOI selection
        self.radioButton_useLayer.toggled.connect(self.on_aoi_method_changed)
        self.pushButton_drawAOI.clicked.connect(self.start_drawing_aoi)
        
        # Date validation
        self.dateEdit_start.dateChanged.connect(self.validate_dates)
        self.dateEdit_end.dateChanged.connect(self.validate_dates)
        
        # Output folder
        self.pushButton_browseOutput.clicked.connect(self.browse_output_folder)
        
        # Actions
        self.pushButton_runAnalysis.clicked.connect(self.run_analysis)
        self.pushButton_downloadResults.clicked.connect(self.download_results)
        self.pushButton_generateMap.clicked.connect(self.generate_professional_map)
        
    def update_auth_status(self):
        """Update authentication status display"""
        if self.gee_processor.check_authentication():
            self.label_authStatus.setText("✅ Authenticated")
            self.label_authStatus.setStyleSheet("color: green;")
            self.is_authenticated = True
            self.pushButton_runAnalysis.setEnabled(True)
        else:
            self.label_authStatus.setText("⚪ Not authenticated")
            self.label_authStatus.setStyleSheet("color: gray;")
            self.is_authenticated = False
            self.pushButton_runAnalysis.setEnabled(False)
            
    def authenticate_gee(self):
        """Authenticate with Google Earth Engine"""
        self.log_message("Authenticating with Google Earth Engine...")
        
        try:
            success = self.gee_processor.authenticate()
            if success:
                QMessageBox.information(
                    self,
                    "Success",
                    "Successfully authenticated with Google Earth Engine!"
                )
                self.update_auth_status()
            else:
                QMessageBox.warning(
                    self,
                    "Authentication Failed",
                    "Failed to authenticate with Google Earth Engine. Please try again."
                )
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"Authentication error: {str(e)}"
            )
            self.log_message(f"Authentication error: {str(e)}", Qgis.Critical)
            
    def on_aoi_method_changed(self):
        """Handle AOI method change"""
        use_layer = self.radioButton_useLayer.isChecked()
        self.mMapLayerComboBox.setEnabled(use_layer)
        self.pushButton_drawAOI.setEnabled(not use_layer)
        
    def start_drawing_aoi(self):
        """Start drawing AOI on canvas"""
        self.log_message("Click on the map to define AOI corners. Right-click to finish.")
        
        # Create rubber band for visualization
        if self.rubber_band:
            self.iface.mapCanvas().scene().removeItem(self.rubber_band)
            
        self.rubber_band = QgsRubberBand(
            self.iface.mapCanvas(),
            QgsWkbTypes.PolygonGeometry
        )
        self.rubber_band.setColor(QColor(255, 0, 0, 100))
        self.rubber_band.setWidth(2)
        
        # Create map tool
        self.draw_tool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.draw_tool.canvasClicked.connect(self.canvas_clicked)
        
        # Set as current map tool
        self.iface.mapCanvas().setMapTool(self.draw_tool)
        
    def canvas_clicked(self, point, button):
        """Handle canvas click for AOI drawing"""
        if button == Qt.LeftButton:
            # Add point to rubber band
            self.rubber_band.addPoint(point, True)
        elif button == Qt.RightButton:
            # Finish drawing
            if self.rubber_band.numberOfVertices() >= 3:
                self.aoi_geometry = self.rubber_band.asGeometry()
                self.log_message(f"AOI defined: {self.aoi_geometry.area() / 1000000:.2f} km²")
                
                # Reset tool
                self.iface.mapCanvas().unsetMapTool(self.draw_tool)
                self.draw_tool = None
            else:
                QMessageBox.warning(
                    self,
                    "Invalid AOI",
                    "Please draw at least 3 points to define an area."
                )
                
    def update_map_preview(self):
        """Update map preview (placeholder)"""
        pass
            
    def validate_dates(self):
        """Validate date range"""
        start = self.dateEdit_start.date()
        end = self.dateEdit_end.date()
        
        if start >= end:
            self.dateEdit_end.setDate(start.addDays(1))
            QMessageBox.warning(
                self,
                "Invalid Date Range",
                "End date must be after start date."
            )
            
    def browse_output_folder(self):
        """Browse for output folder"""
        folder = QFileDialog.getExistingDirectory(
            self,
            "Select Output Folder",
            self.lineEdit_outputFolder.text()
        )
        if folder:
            self.lineEdit_outputFolder.setText(folder)
            
    def get_aoi_geometry(self):
        """Get AOI geometry in WGS84"""
        if self.radioButton_useLayer.isChecked():
            # Get from layer
            layer = self.mMapLayerComboBox.currentLayer()
            if not layer:
                raise ValueError("No layer selected")
                
            # Get all features and union
            features = list(layer.getFeatures())
            if not features:
                raise ValueError("Selected layer has no features")
                
            geom = QgsGeometry.unaryUnion([f.geometry() for f in features])
            
            # Transform to WGS84 if needed
            if layer.crs().authid() != 'EPSG:4326':
                transform = QgsCoordinateTransform(
                    layer.crs(),
                    QgsCoordinateReferenceSystem('EPSG:4326'),
                    QgsProject.instance()
                )
                geom.transform(transform)
                
            return geom
        else:
            # Get from drawn geometry
            if not self.aoi_geometry:
                raise ValueError("No AOI drawn. Please draw an area on the map.")
                
            geom = self.aoi_geometry
            
            # Transform to WGS84 if needed
            canvas_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
            if canvas_crs.authid() != 'EPSG:4326':
                transform = QgsCoordinateTransform(
                    canvas_crs,
                    QgsCoordinateReferenceSystem('EPSG:4326'),
                    QgsProject.instance()
                )
                geom.transform(transform)
                
            return geom
            
    def get_selected_sensors(self):
        """Get list of selected sensors"""
        sensors = []
        if self.checkBox_sentinel2.isChecked():
            sensors.append('sentinel2')
        if self.checkBox_sentinel1.isChecked():
            sensors.append('sentinel1')
        if self.checkBox_landsat8.isChecked():
            sensors.append('landsat8')
        if self.checkBox_landsat9.isChecked():
            sensors.append('landsat9')
        return sensors
        
    def run_analysis(self):
        """Run the mineral exploration analysis"""
        if not self.is_authenticated:
            QMessageBox.warning(
                self,
                "Not Authenticated",
                "Please authenticate with Google Earth Engine first."
            )
            return
            
        try:
            # Prepare parameters
            aoi_geom = self.get_aoi_geometry()
            aoi_json = aoi_geom.asJson() # Serialize to string for thread safety
            sensors = self.get_selected_sensors()
            
            if not sensors:
                QMessageBox.warning(
                    self,
                    "No Sensors Selected",
                    "Please select at least one sensor."
                )
                return
                
            # Date range
            start_date = self.dateEdit_start.date().toString('yyyy-MM-dd')
            end_date = self.dateEdit_end.date().toString('yyyy-MM-dd')
            
            # Parameters
            num_clusters = self.spinBox_clusters.value()
            cloud_cover = self.spinBox_cloudcover.value()
            resolution = int(self.comboBox_resolution.currentText())
            output_folder = self.lineEdit_outputFolder.text()

            # Disable button
            self.pushButton_runAnalysis.setEnabled(False)
            self.log_message("Starting analysis task in background...")
            # Assuming a progressBar widget exists in the UI
            if hasattr(self, 'progressBar'):
                self.progressBar.setValue(0)
            
            # Create and start task
            self.task = AnalysisTask(
                self.gee_processor,
                aoi_json, sensors, start_date, end_date,
                num_clusters, cloud_cover, resolution, output_folder
            )
            
            self.task.taskCompleted.connect(self.on_analysis_finished)
            self.task.taskTerminated.connect(self.on_analysis_error)
            # Connect progress signal
            self.task.progressChanged.connect(lambda p: self.progressBar.setValue(int(p)) if hasattr(self, 'progressBar') else None)
            QgsApplication.taskManager().addTask(self.task)

        except Exception as e:
            QMessageBox.critical(
                self,
                "Analysis Error",
                f"An error occurred during analysis setup:\n{str(e)}"
            )
            self.log_message(f"Analysis setup error: {str(e)}", Qgis.Critical)
            self.pushButton_runAnalysis.setEnabled(True)

    def on_analysis_finished(self):
        """Handle task completion"""
        self.pushButton_runAnalysis.setEnabled(True)
        if hasattr(self, 'progressBar'):
            self.progressBar.setValue(100)
        
        try:
            # results is stored in the task instance
            self.results = self.task.results 
            files = self.results.get('files', {})
            errors = self.results.get('errors', [])
            
            file_info = "\n".join([f"- {k}: {os.path.basename(v)}" for k, v in files.items()])
            
            if not files:
                # Total failure
                err_msg = "\n".join(errors) if errors else "Unknown error (No files downloaded)"
                QMessageBox.critical(
                    self,
                    "Analysis Failed",
                    "No files were downloaded. Errors encountered:\n\n" + err_msg
                )
                self.log_message(f"Analysis failed. Errors: {err_msg}", Qgis.Critical)
            elif errors:
                # Partial success
                err_msg = "\n".join(errors)
                QMessageBox.warning(
                    self,
                    "Partial Success",
                    f"Analysis completed but some files failed:\n\nErrors:\n{err_msg}\n\nSaved Files:\n{file_info}"
                )
                self.log_message(f"Analysis finished with errors: {err_msg}", Qgis.Warning)
                self.pushButton_downloadResults.setEnabled(True)
            else:
                # Success
                QMessageBox.information(
                    self,
                    "Analysis Complete",
                    "Analysis completed successfully! Files saved locally:\n\n"
                    f"{file_info}\n\n"
                    f"Folder: {self.lineEdit_outputFolder.text()}"
                )
                self.log_message("Analysis finished successfully.")
                self.pushButton_downloadResults.setEnabled(True)
            
        except Exception as e:
            self.on_analysis_error() # Call error handler for result processing issues
            self.log_message(f"Error processing results: {str(e)}")

    def on_analysis_error(self):
        """Handle task error"""
        self.pushButton_runAnalysis.setEnabled(True)
        if hasattr(self, 'progressBar'):
            self.progressBar.setValue(0) # Reset progress bar on error
        
        # Use exception from task if available
        err = "Unknown error"
        if hasattr(self.task, 'exception') and self.task.exception:
            err = str(self.task.exception)
            
        QMessageBox.critical(self, "Analysis Error", f"Task failed:\n{err}\n\nTry reducing resolution (30m) or area size.")
        self.log_message(f"Analysis failed: {err}")

    def download_results(self):
        """Download results from Google Drive"""
        # This would implement downloading from Google Drive
        # For now, just show a message
        QMessageBox.information(
            self,
            "Download Results",
            "Results have been exported to your Google Drive.\n\n"
            "Please download them manually from:\n"
            "Google Drive > GEE_Mineral_Exploration\n\n"
            "Then use 'Add Layer' in QGIS to load the GeoTIFF and Shapefile."
        )
        
    def generate_professional_map(self):
        """Generate professional map layout"""
        if not self.results:
            QMessageBox.warning(
                self,
                "No Results",
                "Please run analysis first before generating a map."
            )
            return
            
        try:
            self.log_message("Generating professional map...")
            
            # Generate map
            layout = self.map_composer.create_professional_layout(
                self.results,
                self.get_aoi_geometry(),
                self.get_selected_sensors(),
                self.dateEdit_start.date().toString('yyyy-MM-dd'),
                self.dateEdit_end.date().toString('yyyy-MM-dd')
            )
            
            # Export to PDF
            output_folder = self.lineEdit_outputFolder.text()
            os.makedirs(output_folder, exist_ok=True)
            
            pdf_path = os.path.join(
                output_folder,
                f"mineral_exploration_map_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
            )
            
            self.map_composer.export_to_pdf(layout, pdf_path)
            
            QMessageBox.information(
                self,
                "Map Generated",
                f"Professional map exported to:\n{pdf_path}"
            )
            
            self.log_message(f"Map exported to: {pdf_path}")
            
        except Exception as e:
            QMessageBox.critical(
                self,
                "Map Generation Error",
                f"An error occurred while generating the map:\n{str(e)}"
            )
            self.log_message(f"Map generation error: {str(e)}", Qgis.Critical)
            
    def log_message(self, message, level=Qgis.Info):
        """Log message to QGIS message log"""
        QgsMessageLog.logMessage(message, 'GeoMiningOpt', level)
        self.textEdit_log.append(f"[{datetime.now().strftime('%H:%M:%S')}] {message}")
        QApplication.processEvents()
        
    def closeEvent(self, event):
        """Handle dialog close event"""
        # Clean up drawing tool
        if self.draw_tool:
            self.iface.mapCanvas().unsetMapTool(self.draw_tool)
        if self.rubber_band:
            self.iface.mapCanvas().scene().removeItem(self.rubber_band)
            
        self.closingPlugin.emit()
        event.accept()
